📺 DISPLAYS PLAYBOOK
Pages

/display_centre.html (selector/commands)

/scoreboard.html (per-heat)

/leaderboard.html (event standings)

/intro.html (splash/countdown)

Data Sources

Reads from scores_{cid}_{eid}_{heat} and competition meta via localStorage and sync bus.

Notes

Multiple displays are allowed; each page can be opened in its own tab/window.

Control page may open display pages with cid/eid/heat params.