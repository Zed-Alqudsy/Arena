🏆 COMPETITION PLAYBOOK
Pages

New Setup (skeleton): /modules/competition/setup.html

Control (skeleton): /modules/competition/control.html

Legacy Setup/List/Home: /pages/competition_*.html

Legacy Run/Heat: /pages/run_console.html, /pages/heat_select.html

Displays: /display_centre.html, /scoreboard.html, /leaderboard.html, /intro.html

Flow (today)

Use legacy for creating/listing/home.

Use legacy for run & heat select.

Use legacy displays (open via new Control links).

Next

Add display selector dropdown in new Control.

Embed quick Judges edit in new Control.

Later: heats editor in new Setup.